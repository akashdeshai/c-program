﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_while.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.WriteLine("for loop:");
            for (i = 1; i < 5; i++)
            {
                Console.WriteLine(i + "");
            }
            Console.WriteLine("while loop");
            i = 1;
            while (i <= 5)
            {
                Console.WriteLine(i + "");
            }
            Console.WriteLine("do while loop:");
            i = 1;
            do
            {
                Console.WriteLine(i + "");
                i++;
            }
            while (i <= 5);
            Console.Read();
        }
    }
}
