﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_do_while.cs
// fibonacci series
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i, a = 0, b = 1, c;
            Console.Write("Input no.:");
            n = Convert.ToInt32(Console.ReadLine());
            for(i=a ; i<=n ; i++)
            {
                Console.Write(a + ",");
                c = a + b;
                a = b;
                b = c;
            }
            Console.WriteLine("while loop:");
            a = 0; b = 1; i = a;
            while(i<=n)
            {
                Console.Write(a + "");
                c = a + b;
                a = b;
                b = c;
                i++;
            }
            Console.WriteLine("Do_while loop:");
            a = 0; b = 1; i = a;
            do
            {
                Console .Write (a+"");
                c=a+b;
                a=b;
                b=c;
                i++;
            }
            while(i<=5);
            Console.Read(); 
        }
    }
}
