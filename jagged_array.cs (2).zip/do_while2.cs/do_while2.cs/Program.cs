﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_while2.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, a = 1, b = 2, n;
            Console.WriteLine("Enter no.:");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("for loop");
            Console.Write(a + "" + b + "");
            for(i=3;i<=n;i++)
            {
                if(i%2==1)
                {
                    a = a * 3;
                    Console .Write (a+"");
                }
                else
                {
                    b=b*3;
                    Console.Write (b+"");
                }
            }
            Console .WriteLine ("");
            a=1;b=2;i=3;
            Console .WriteLine ("while loop");
            Console .Write (a+""+b+"");
            while (i<=n )
            {
                if(i%2==1)
                {
                    a=a*3;
                    Console .Write (a+"");
                }
                else
                {
                    b=b*3;
                    Console .Write (b+"");
                }
                i++;
            }
            Console.WriteLine ("");
            a=1,b=2,i=3;
            Console.WriteLine ("do.....while loop:");
            Console.Write (a+""+b+"");
            do
            {
                if(i%2==1)
                {
                    a=a*3;
                    Console .Write (a+"");
                }
                else
                {
                    b=b*3;
                    Console .Write (b+"");
                }
                while(i<=n);
                Console .Read();
            }
        }
    }
}
