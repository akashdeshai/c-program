﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace first.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            string nm = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Name :" + nm);
            Console.Read();
        }
    }
}
