﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rectengular_array.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] a = new int[2, 2] { { 2, 2 }, { 3, 4 } };
            int i,j;
            for(i=0;i<=2;i++)
            {

                for(j=0;j<2;j++)
                {
                    Console.Write (a[i,j]);
                }
                Console .WriteLine();
            }
            Console .Read ();
        }
    }
}
