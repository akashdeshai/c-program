﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fibonaccy_whie.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3, count = 10;
            n1 = 0;
            n2 = 1;
            int i = 2;
            Console.Write (n1+""+n2);
            while(i!=count)
            {
                n3=n1+n2;
                Console.Write (""+n3);
                n1=n2;
                n2=n3;
                i++;
            }
            Console .Read ();
        }
    }
}
