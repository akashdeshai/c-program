﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marksheet.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1, m2, m3, total;
            float avg;
            Console.WriteLine("Enter Marks");
            m1 = Convert.ToInt32(Console.ReadLine());
            m2 = Convert.ToInt32(Console.ReadLine());
            m3 = Convert.ToInt32(Console.ReadLine());

            total = m1 + m2 + m3;
            avg = total / 3;
            if (avg > 80)
            {
                Console.WriteLine("A");
            }
            else if(avg<=80 && avg>=60)
            {
                Console.WriteLine("B");
            }
            else if(avg<=60 && avg>=40)
            {
                Console.WriteLine("Fail");
            }
            Console.Read();
        }
    }
}
