﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AOP.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("input valur of a & b:");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            c = a + b;
            Console.WriteLine("Add=" + c);
            c = a - b;
            Console.WriteLine("Sub=" + c);
            c = a * b;
            Console.WriteLine("Mul=" + c);
            c = a / b;
            Console.WriteLine("Div=" + c);
            c = a % b;
            Console.WriteLine("Modulos=" + c);

            Console.Read();n
        }
    
    }
}
